#' CHAT package
#'
#' Contains functions to load and visualize climate models
#' @docType package
#'
#' @author Riccardo Soldan \email{riccardosoldan@hotmail.it}
#'
#' @name CHAT
NULL
